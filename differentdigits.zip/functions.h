// Header file's header
#ifndef functions_h // these names can't begin with numbers, so I omitted 03_
#define functions_h


int countDigitOccurence(int n, int digit);



#endif
