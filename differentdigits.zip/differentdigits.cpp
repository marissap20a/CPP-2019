#include <iostream>
#include "functions.h"
using namespace std;
int k;
int DigitOccurences;
int l;
int digit;
int repeatNumCount = 0; 
int main() {
    int a,b;
	cout << "Enter numbers a <= b: ";
	cin >> a >> b;
	
	if ( (a <= 0) || (a > 10000) || (b <= 0) || (b >10000) || (a > b)) {
		cout << "Invalid input" << endl;
	}
	
	else {
		for (l = a; l <= b; ++l){
			for (k = 0; k < 10; ++k){
				DigitOccurences = countDigitOccurence(l,k);
				if (DigitOccurences >= 2){
					//cout << "There is a repeated value of " << k << " in " << l << endl;
					repeatNumCount +=1;
				}
	
			}
			
		}
		cout << "There are " << (b-a)+1-repeatNumCount << " valid numbers between " << a << " and " << b << endl; 
		
		
	}
	
	
	
	/*for (k = 0; k < 10; ++k){
		DigitOccurences = countDigitOccurence(1002,k);
		if (DigitOccurences >= 2){
			cout << "There is a repeated value of " << k << " in " << "1202" << endl;
		}
	
	}
	*/
	
	
	
	
	
	
	return 0;
}
